$(function() { 

    $('.indi a').click(function(e) {
        e.preventDefault();
        let swt = $('.poster_list').hasClass('on');

        if (swt) {
            $('.poster_list').removeClass('on');
            $('#poster_container2').addClass('on');
            $('.roll a').removeClass('active').eq(1).addClass('active');
        } else {
            $('#poster_container2').removeClass('on');
            $('.poster_list').addClass('on');
            $('.roll a').removeClass('active').eq(0).addClass('active');
        }
    });

    $('.roll a').click(function(e) {
        e.preventDefault();
        let idx = $(this).index();
        $('.roll a').removeClass('active');
        $(this).addClass('active');

        if (idx === 0) {
            $('.poster_list').addClass('on');
            $('#poster_container2').removeClass('on');
        } else {
            $('.poster_list').removeClass('on');
            $('#poster_container2').addClass('on');
        }
    });


    let adIdx = 0;
    let adTimer;
    const adCount = 4; 

    function moveAd(index) {
        $('.ad-list').css({
            'transition': 'transform 0.5s ease-in-out',
            'transform': 'translateX(-' + (index * 20) + '%)'
        });

        let dotIdx = (index === adCount) ? 0 : index;
        $('.ad-roll a').removeClass('ad-active').eq(dotIdx).addClass('ad-active');
        adIdx = index;

        if (index === adCount) {
            setTimeout(function() {
                $('.ad-list').css({
                    'transition': 'none', 
                    'transform': 'translateX(0%)'
                });
                adIdx = 0; 
            }, 500); 
        }
    }

    function startTimer() {
        clearInterval(adTimer);
        adTimer = setInterval(function() {
            moveAd(adIdx + 1);
        }, 4000); 
    }

    startTimer();

    $('.ad-roll a').click(function(e) {
        e.preventDefault();
        clearInterval(adTimer);
        let clickedIdx = $(this).index();
        moveAd(clickedIdx);
        startTimer();
    });


    $(".copy-img").on('click', function(e) {
        e.preventDefault();
        alert("주소가 복사되었습니다.");
    });

});



function toggleFooter() {
    const details = document.getElementById('footerDetail');
    const arrowIcon = document.querySelector('.arrow-icon img');

    if (details.style.display === 'block') {
        details.style.display = 'none';
        arrowIcon.style.transform = 'rotate(0deg)';
    } else {
        details.style.display = 'block';
        arrowIcon.style.transform = 'rotate(180deg)';
    }
}