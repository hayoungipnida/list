<?php
include "dbconn.php";
mysqli_query($connect, "set names utf8");

echo "=== 배치 시작: " . date('Y-m-d H:i:s') . " ===<br>";

// 1. 1년 이상 미접속 휴면 처리
mysqli_query($connect, "
    UPDATE mb1
    SET status = 'inactive'
    WHERE last_login < DATE_SUB(NOW(), INTERVAL 1 YEAR)
");
$affected1 = mysqli_affected_rows($connect);
echo "1. 휴면 처리: {$affected1}명<br>";

// 2. 로그인 실패 횟수 초기화
mysqli_query($connect, "
    UPDATE mb1
    SET fail_count = 0
    WHERE fail_count > 0
");
$affected2 = mysqli_affected_rows($connect);
echo "2. 실패 횟수 초기화: {$affected2}명<br>";

echo "=== 배치 완료: " . date('Y-m-d H:i:s') . " ===<br>";
?>