<!doctype html>
<html lang="ko">
	<head>
		<meta charset="utf-8">
		<title>html5문서</title>
		<link rel="stylesheet" href="css/reset.css">
		<link rel="stylesheet" href="css/base.css">
		<link rel="stylesheet" href="css/main.css">
<style>
	h1 {text-align:center;}
</style>
</head>
<body>
<h1><a href="main.html"> HOME</a> </h1>
<div id="login">
<form  name="member_form" method="post" action="login.php"> 	
<p>
<label for="name">ID</label>
<input type="text" id="name" name="id">	
</p>
<p>
<label for="pwd">Password</label>
<input type="password" id="pwd" name="pass">	
</p>
 <p class="center">
<input type="submit"  value="로그인">
<a href="member_form.php">회원가입</a>
</p>
</form>
</div>
  
</body>
</html>