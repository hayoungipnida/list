document.addEventListener("DOMContentLoaded", function(){
   const select = document.querySelector("select");
   const ul = document.querySelector("#content ul");

   select.addEventListener("change",function(){
    const ab =this.value;
            const lis = Array.from(document.querySelectorAll("#content ul > li"));
           

            const strName = ab;
        slideTarget(strName.substr(4,1));
        function slideTarget(n) {
            let datelis;
            if(n == "0") {
                location.reload(true);

            } else if (n == "1") { 
              
                datelis = lis.sort((a,b)=> {
                    const dateA = new Date(a.querySelector("span.date").textContent);
                    const dateB = new Date(b.querySelector("span.date").textContent);
                    return dateB-dateA; 
                });
            } else if ( n =="2") { 
                
                datelis =lis.sort((a,b) => {
                    const rateA = parseInt(a.querySelector("span.rate").textContent.replace(/[^0-9]/g,''));
                    const rateB = parseInt(b.querySelector("span.rate").textContent.replace(/[^0-9]/g,''));
                    return rateB-rateA;
                });
                
            } else {
                datelis = lis.sort((a,b) => {
                    const priceA = parseInt(a.querySelector("span.price").textContent.replace(/[^0-9]/g,''));
                    const priceB = parseInt(b.querySelector("span.price").textContent.replace(/[^0-9]/g,''));
                    return priceA-priceB;
                });
            } 
        
            if (datelis){
                ul.innerHTML = "";
                datelis.forEach(function(li){
                    ul.appendChild(li);
                });
            }
        }
        });
    });