$(function(){
   $('select').on("change", function(){
    const ab= $(this).val();
    const $lis = $("ul>li");
        const strName = ab;

        slideTarget(strName.substr(4,1)); 
        function slideTarget(n) {
            let datelis;

            if (n === "0"){
                location.reload(true);

            } else if (n === "1") {
               
                datelis = $lis.sort((a,b)=> {
                    const dateA = new Date($(a).find("span.date").text());
                    const dateB = new Date($(b).find("span.date").text());
                    return dateB-dateA; 
                });
            } else if ( n==="2") {
                //별점
                datelis =$lis.sort((a,b) => {
                    const rateA = parseInt($(a).find("span.rate").text().replace(/[^0-9]/g,''));
                    const rateB = parseInt($(b).find("span.rate").text().replace(/[^0-9]/g,''));
                    return rateB-rateA;
                });
                
            } else {
                datelis = $lis.sort((a,b) => {
                    const priceA = parseInt($(a).find("span.price").text().replace(/[^0-9]/g,''));
                    const priceB = parseInt($(b).find("span.price").text().replace(/[^0-9]/g,''));
                    return priceA-priceB;
                });
            } 
            $("#content ul").html(datelis);
        }
});
});
