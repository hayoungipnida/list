<?
    session_start();
?>
<!doctype html>
<html lang="ko">
<head>
<meta charset="utf-8">
<title>비밀번호 찾기</title>
<link rel="stylesheet" href="css/reset.css">
<link rel="stylesheet" href="css/base.css">
<style>
body, html {
    width: 100%;
    height: 100%;
    margin: 0;
    padding: 0;
    background-color: #f8fafc;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
}
#pw_mem {
    width: 400px;
    transform: translate(-50%, -50%);
    position: absolute;
    left: 50%;
    top: 50%;
    padding: 30px;
    background: #ffffff;
    border: 1px solid #e2e8f0;
    border-radius: 12px;
    box-shadow: 0 10px 25px -5px rgba(0,0,0,0.05);
}
h2 {
    text-align: center;
    margin-bottom: 20px;
    font-size: 18px;
    color: #1e293b;
}
ul { list-style: none; padding: 0; }
ul li {
    margin-bottom: 14px;
    display: flex;
    align-items: center;
}
label {
    display: inline-block;
    width: 80px;
    font-size: 13px;
    font-weight: 600;
    color: #475569;
}
input[type=text], input[type=tel] {
    flex: 1;
    height: 36px;
    border: 1px solid #cbd5e1;
    border-radius: 6px;
    padding: 0 10px;
    font-size: 13px;
    color: #1e293b;
    box-sizing: border-box;
}
input[type=text]:focus, input[type=tel]:focus {
    outline: none;
    border-color: #2563eb;
    box-shadow: 0 0 0 3px rgba(37,99,235,0.15);
}
#write_button {
    text-align: center;
    margin-top: 20px;
}
input[type=submit] {
    height: 36px;
    padding: 0 30px;
    background-color: #2563eb;
    color: #ffffff;
    border: none;
    border-radius: 6px;
    font-size: 13px;
    font-weight: 600;
    cursor: pointer;
}
input[type=submit]:hover {
    background-color: #1d4ed8;
}
.nav-home {
    text-align: center;
    margin-bottom: 15px;
    font-size: 11px;
}
.nav-home a {
    color: #94a3b8;
    text-decoration: none;
    font-weight: 700;
}
.nav-home a:hover { color: #2563eb; }
</style>
</head>
<body>
<div id="pw_mem">
    <p class="nav-home"><a href="main.html">HOME</a></p>
    <h2>비밀번호 찾기</h2>
    <form name="pw_form" method="post" action="pw_search.php">
    <ul>
        <li>
            <label for="pid">ID</label>
            <input type="text" name="id" id="pid">
        </li>
        <li>
            <label for="a2">HP</label>
            <input type="tel" name="hp" id="a2">
        </li>
    </ul>
    <div id="write_button">
        <input type="submit" value="확인">
    </div>
    </form>
</div>
</body>
</html>