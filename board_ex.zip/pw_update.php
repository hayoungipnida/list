<?
    session_start();
?>
<meta charset="utf-8">
<?php
    if(!$_SESSION['reset_id']){
        echo "<script>alert('잘못된 접근입니다.'); location.href='main.html';</script>";
        exit;
    }

    $pass = password_hash($_POST['pass'], PASSWORD_DEFAULT);
    $id = $_SESSION['reset_id'];

    include "dbconn.php";
    $sql = "update mb1 set pass='$pass' where id='$id'";
    mysqli_query($connect, $sql);
    mysqli_close($connect);

    session_destroy();
    echo "<script>alert('비밀번호가 변경되었습니다. 다시 로그인해주세요.'); location.href='login_form.php';</script>";
?>