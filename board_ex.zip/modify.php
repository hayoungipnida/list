<?
    session_start();
	include "session_check.php";
?>
<meta charset="utf-8">
<?php
$userid=$_POST['id'];
$pass = password_hash($_POST['pass'], PASSWORD_DEFAULT); 
$name = $_POST['name'];
$hp = $_POST['hp'];
include "dbconn.php";      
mysqli_query($connect,'set names utf8');  
$sql = "update mb1 set pass='$pass', name='$name',";
$sql .= "hp='$hp' where id='$_SESSION[userid]'";

$result = mysqli_query( $connect,$sql) ;
mysqli_close($connect);
echo "
	   <script>
	    location.href = 'main.html';
	   </script>
	";
?>