<?
    session_start();
?>
<meta charset="utf-8">
<?
    include "dbconn.php";
    mysqli_query($connect,'set names utf8');  

    $id = $_POST['id'];
    $hp = $_POST['hp'];

    $sql = "select * from mb1 where id='$id' AND hp='$hp'";
    $result = mysqli_query($connect, $sql);
    $num_match = mysqli_fetch_array($result);

    if(!empty($num_match)){
        $_SESSION['reset_id'] = $id;  
        echo "<script>alert('본인 확인 완료! 새 비밀번호를 설정해주세요.'); location.href='pw_reset.php';</script>";
    } else {
        echo "<script>alert('비밀번호 찾기 실패'); location.href='main.html';</script>";
    }
    mysqli_close($connect);
?>