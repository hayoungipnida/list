<?php
session_start();
include "session_check.php";

$num=$_GET['num'];
include "dbconn.php";
if (!isset($_SESSION['userid'])) {
      echo("
		<script>
	     window.alert('로그인 후 삭제가능.')
	     history.go(-1);
	   </script>
		");
     exit;
  }else{
   $sql = "delete from boardlist where num = $num";
}
/** @var mysqli $connect */
mysqli_query( $connect,$sql);
 mysqli_close($connect);

   echo "
	   <script>
	    location.href = 'list.php';
	   </script>
	";
?>