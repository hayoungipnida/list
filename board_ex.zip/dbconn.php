<?
 $connect=mysqli_connect( "localhost", "ha0", "wjdgkdud1!","ha0") or  
        die( "SQL server에 연결할 수 없습니다."); 

    mysqli_select_db($connect,"ha0");
?>