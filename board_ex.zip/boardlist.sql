create table boardlist(
   num int not null auto_increment,
   id varchar(15) not null,
   name varchar(10) not null,
   subject varchar(200) not null,
   content text not null,
   regist_day datetime default current_timestamp, 
   hit int default 0,     
   is_html varchar(1) default 'N', 
   primary key(num)
)engine=innoDB charset=utf8;