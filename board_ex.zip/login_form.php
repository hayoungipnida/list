<!doctype html>
<html lang="ko">
    <head>
        <meta charset="utf-8">
        <title>html5문서</title>
        <link rel="stylesheet" href="css/reset.css">
        <link rel="stylesheet" href="css/base.css">
        <link rel="stylesheet" href="css/main.css">
<style>
    h1 {text-align:center;}
    .find-links {
        text-align: center;
        margin-top: 10px;
        font-size: 13px;
    }
    .find-links a {
        color: #64748b;
        text-decoration: none;
        padding: 0 8px;
    }
    .find-links a:hover {
        color: #2563eb;
    }
    .find-links span {
        color: #cbd5e1;
    }
</style>
</head>
<body>
<h1><a href="main.html">HOME</a></h1>
<div id="login">
<form name="member_form" method="post" action="login.php"> 	
<p>
<label for="name">ID</label>
<input type="text" id="name" name="id">	
</p>
<p>
<label for="pwd">Password</label>
<input type="password" id="pwd" name="pass">	
</p>
<p class="center">
<input type="submit" value="로그인">
<a href="member_form.php">회원가입</a>
</p>
</form>
<div class="find-links">
    <a href="id_screen.php">아이디 찾기</a>
    <span>|</span>
    <a href="pw_form.php">비밀번호 찾기</a>
</div>
</div>
</body>
</html>