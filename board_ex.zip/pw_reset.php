<?
    session_start();
    if(!$_SESSION['reset_id']){
        echo "<script>alert('잘못된 접근입니다.'); location.href='main.html';</script>";
        exit;
    }
?>
<!doctype html>
<html lang="ko">
<head>
<meta charset="utf-8">
<title>비밀번호 재설정</title>
<link rel="stylesheet" href="css/reset.css">
<link rel="stylesheet" href="css/base.css">
<style>
body, html {
    width: 100%;
    height: 100%;
    margin: 0;
    padding: 0;
    background-color: #f8fafc;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
}
#reset_mem {
    width: 400px;
    transform: translate(-50%, -50%);
    position: absolute;
    left: 50%;
    top: 50%;
    padding: 30px;
    background: #ffffff;
    border: 1px solid #e2e8f0;
    border-radius: 12px;
    box-shadow: 0 10px 25px -5px rgba(0,0,0,0.05);
}
h2 {
    text-align: center;
    margin-bottom: 20px;
    font-size: 18px;
    color: #1e293b;
}
ul { list-style: none; padding: 0; }
ul li {
    margin-bottom: 14px;
    display: flex;
    align-items: center;
}
label {
    display: inline-block;
    width: 110px;
    font-size: 13px;
    font-weight: 600;
    color: #475569;
}
input[type=password] {
    flex: 1;
    height: 36px;
    border: 1px solid #cbd5e1;
    border-radius: 6px;
    padding: 0 10px;
    font-size: 13px;
    color: #1e293b;
    box-sizing: border-box;
}
input[type=password]:focus {
    outline: none;
    border-color: #2563eb;
    box-shadow: 0 0 0 3px rgba(37,99,235,0.15);
}
#write_button {
    text-align: center;
    margin-top: 20px;
}
input[type=button] {
    height: 36px;
    padding: 0 30px;
    background-color: #2563eb;
    color: #ffffff;
    border: none;
    border-radius: 6px;
    font-size: 13px;
    font-weight: 600;
    cursor: pointer;
}
input[type=button]:hover {
    background-color: #1d4ed8;
}
</style>
<script>
function check_reset() {
    if(!document.reset_form.pass.value) {
        alert('새 비밀번호를 입력하세요.');
        return;
    }
    if(!document.reset_form.pass_confirm.value) {
        alert('비밀번호 확인을 입력하세요.');
        return;
    }
    if(document.reset_form.pass.value != document.reset_form.pass_confirm.value) {
        alert('비밀번호가 일치하지 않습니다.');
        return;
    }
    document.reset_form.submit();
}
</script>
</head>
<body>
<div id="reset_mem">
    <h2>비밀번호 재설정</h2>
    <form name="reset_form" method="post" action="pw_update.php">
    <ul>
        <li>
            <label>새 비밀번호</label>
            <input type="password" name="pass">
        </li>
        <li>
            <label>비밀번호 확인</label>
            <input type="password" name="pass_confirm">
        </li>
    </ul>
    <div id="write_button">
        <input type="button" value="변경하기" onclick="check_reset()">
    </div>
    </form>
</div>
</body>
</html>