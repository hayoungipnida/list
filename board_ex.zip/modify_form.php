<? 
	session_start(); 
    include "session_check.php";
	include "dbconn.php";
	$num=$_GET['num'];

/** @var mysqli $connect */
	$sql = "select * from boardlist where num=$num";
	$result = mysqli_query( $connect,$sql);

	$row = mysqli_fetch_array($result);       	
	$item_subject     = $row['subject'];
	$item_content     = $row['content'];
?>
<html>
<head> 
<meta charset="utf-8">
<link rel="stylesheet" href="css/reset.css">

<style>
    body, html {
        width: 100%;
        height: 100%;
        margin: 0;
        padding: 0;
        background-color: #f8fafc;
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
    }

    #wrap {
        width: 100%;
        max-width: 800px;
        margin: 40px auto;
        padding: 0 20px;
        box-sizing: border-box;
    }

    #content #col2 {
        width: 100%;
    }

    #write_form_box {
        background: #ffffff;
        border: 1px solid #e2e8f0;
        border-radius: 12px;
        box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.05), 0 8px 10px -6px rgba(0, 0, 0, 0.05);
        padding: 30px 25px;
        box-sizing: border-box;
    }

    #write_form_title {
        font-size: 16px;
        font-weight: 700;
        color: #1e293b;
        margin-bottom: 20px;
        padding-bottom: 10px;
        border-bottom: 2px solid #e2e8f0;
        letter-spacing: -0.5px;
    }

    #write_form {
        display: flex;
        flex-direction: column;
        gap: 14px;
    }

    .write_row {
        display: flex;
        flex-direction: column;
        gap: 5px;
    }

    .write_row .col1 {
        font-size: 12px;
        font-weight: 600;
        color: #475569;
        letter-spacing: -0.3px;
    }

    .write_row .col2 {
        width: 100%;
    }

    .write_row .col2-group {
        display: flex;
        align-items: center;
        background-color: #f1f5f9;
        padding: 0 12px;
        border-radius: 6px;
        height: 36px;
        box-sizing: border-box;
    }

    #write_row1 .col2 {
        font-size: 13px;
        font-weight: 700;
        color: #1e293b;
    }

    #write_row2 .col2 input {
        width: 100%;
        height: 36px;
        border: 1px solid #cbd5e1;
        border-radius: 6px;
        color: #1e293b;
        font-size: 13px;
        padding: 0 10px;
        background-color: #ffffff;
        box-sizing: border-box;
        transition: border-color 0.2s, box-shadow 0.2s;
    }

    #write_row2 .col2 input:focus {
        outline: none;
        border-color: #2563eb;
        box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.15);
    }

    #write_row3 .col2 textarea {
        width: 100%;
        border: 1px solid #cbd5e1;
        border-radius: 6px;
        color: #1e293b;
        font-size: 13px;
        padding: 10px;
        background-color: #ffffff;
        box-sizing: border-box;
        resize: vertical;
        min-height: 220px;
        font-family: inherit;
        transition: border-color 0.2s, box-shadow 0.2s;
    }

    #write_row3 .col2 textarea:focus {
        outline: none;
        border-color: #2563eb;
        box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.15);
    }

    #write_button {
        margin-top: 24px;
        display: flex;
        justify-content: flex-end;
        gap: 8px;
    }

    .btn-submit, .btn-list {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        height: 36px;
        padding: 0 20px;
        font-size: 12px;
        font-weight: 600;
        text-decoration: none;
        border-radius: 6px;
        box-sizing: border-box;
        cursor: pointer;
        transition: all 0.2s ease-in-out;
    }

    .btn-submit {
        background-color: #2563eb;
        color: #ffffff;
        border: none;
    }

    .btn-submit:hover {
        background-color: #1d4ed8;
    }

    .btn-list {
        background-color: #ffffff;
        color: #475569;
        border: 1px solid #cbd5e1;
    }

    .btn-list:hover {
        background-color: #f8fafc;
        color: #1e293b;
        border-color: #94a3b8;
    }
</style>


</head>

<body>

<div id="wrap">
  

  <div id="content">
	

	<div id="col2">        
		<div id="title">
			<img src="image/title_greet.gif">
		</div>

		<div class="clear"></div>

		<div id="write_form_title">
			<img src="image/write_form_title.gif">
		</div>
<? $page = 1; ?>
		<div class="clear"></div>
		<form  name="board_form" method="post" action="insert1.php?mode=modify&num=<?=$num?>&page=<?=$page?>"> 
		<div id="write_form">
			<div class="write_line"></div>
			<div id="write_row1">
				<div class="col1"> 닉네임 </div>
				<div class="col2">
					<?=$_SESSION['userid']?>
				</div>
			</div>
			<div class="write_line"></div>
			<div id="write_row2"><div class="col1"> 제목   </div>
			 <div class="col2">
				<input type="text" name="subject" value="<?=$item_subject?>" >
			 </div>
			</div>
			<div class="write_line"></div>
			<div id="write_row3"><div class="col1"> 내용   </div>
			<div class="col2"><textarea rows="15" cols="79" name="content">
				<?=$item_content?></textarea></div>
			</div>
			<div class="write_line"></div>
		</div>

		<div id="write_button"><input type="image" src="image/ok.png">&nbsp;
		<a href="list.php?page=<?=$page?>"><img src="image/list.png"></a>
		</div>  
		</form>

	</div> <!-- end of col2 -->
  </div> <!-- end of content -->
</div> <!-- end of wrap -->

</body>
</html>