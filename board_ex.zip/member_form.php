<?
	session_start();
?>
<!doctype html>
<html lang="ko">
	<head>
		<meta charset="utf-8">
		<title>html5문서</title>
		<link rel="stylesheet" href="css/reset.css">

<script>
function check_id()
   {
     window.open("check_id.php?id=" + document.member_form.id.value,
         "IDcheck",
          "left=200,top=200,width=200,height=60,scrollbars=no,resizable=yes");
   }
   
   function check_input()
   {

 const re1 =/^(?=.*[a-zA-Z])(?=.*[0-9]).{6,10}$/;
    const id=document.member_form.id.value;
      if (!document.member_form.id.value)
      {
          alert("아이디를 입력하세요");    
          document.member_form.id.focus();
          return;
      }else if(!re1.test(id)){
        alert("아이디는 6~10자로, 영문자,숫자를 혼합해서 만들어주세요");
    return false;
      }

const re_pass = /^(?=.*[a-zA-Z])(?=.*[!@#$%^*+=-])(?=.*[0-9]).{6,15}$/;
const pass = document.member_form.pass.value;
if (!document.member_form.pass.value)
      {
          alert("비밀번호를 입력하세요");    
          document.member_form.pass.focus();
          return;
      }else if(!re_pass.test(pass)){
        alert("비밀번호는 6~15자로, 영문자, 숫자와 특수문자를 모두 포함하여 만들어주세요");
    return false;
      }
	
if (!document.member_form.pass_confirm.value)
      {
          alert("비밀번호를 다시 한 번 입력해주세요");    
          document.member_form.pass_confirm.focus();
          return;
      }

if (document.member_form.pass.value != 
    document.member_form.pass_confirm.value)
{
 alert("비밀번호가 일치하지 않습니다.\n다시 입력해주세요.");
  document.member_form.pass.focus();
  document.member_form.pass.select();
  return; 
}

if (!document.member_form.name.value)
      {
          alert("이름을 입력하세요");    
          document.member_form.name.focus();
          return;
      }

           if (!document.member_form.hp.value)
      {
          alert("휴대폰 번호를 입력하세요");    
          document.member_form.hp.focus();
          return;
      }

   document.member_form.submit();
}

 function reset_form(){
	  document.member_form.id.value = "";
      document.member_form.pass.value = "";
      document.member_form.pass_confirm.value = "";
      document.member_form.name.value = "";
      document.member_form.hp.value = "";
      
      document.member_form.id.focus();

      return;
 }
</script>
<style>
    body, html {
        width: 100%;
        height: 100%;
        margin: 0;
        padding: 0;
        background-color: #f8fafc;
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
    }


    #join_mem {
        width: 440px;
        position: absolute;
        left: 50%;
        top: 50%;
        transform: translate(-50%, -50%);
        background: #ffffff;
        border: 1px solid #e2e8f0;
        border-radius: 12px;
        box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.05), 0 8px 10px -6px rgba(0, 0, 0, 0.05);
        padding: 40px 30px;
        box-sizing: border-box;
    }

    h2 {
        text-align: center;
        margin-bottom: 30px;
        font-size: 22px;
        font-weight: 700;
        color: #1e293b;
        letter-spacing: -0.5px;
    }

    #form_join {
        width: 100%;
    }

    #join1 ul {
        margin: 0;
        padding: 0;
        list-style: none;
    }

    #join1 ul li {
        margin-bottom: 18px;
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 10px;
    }


    #join1 ul label {
        display: inline-block;
        width: 95px;
        font-size: 13px;
        font-weight: 600;
        color: #475569;
        letter-spacing: -0.3px;
    }


    #join1 ul input[type="text"],
    #join1 ul input[type="password"] {
        flex: 1;
        height: 38px;
        border: 1px solid #cbd5e1;
        border-radius: 6px;
        color: #1e293b;
        font-size: 13px;
        padding: 0 12px;
        background-color: #ffffff;
        box-sizing: border-box;
        transition: border-color 0.2s, box-shadow 0.2s;
    }

    #join1 ul input:focus {
        outline: none;
        border-color: #2563eb;
        box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.15);
    }

    /* 중복 확인 버튼 CSS화 */
    .btn-check {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        height: 38px;
        padding: 0 14px;
        font-size: 12px;
        font-weight: 600;
        color: #2563eb;
        background-color: #ffffff;
        border: 1px solid #2563eb;
        border-radius: 6px;
        text-decoration: none;
        white-space: nowrap;
        transition: all 0.2s ease-in-out;
    }

    .btn-check:hover {
        background-color: #2563eb;
        color: #ffffff;
    }


    #button {
        margin-top: 32px;
        display: flex;
        justify-content: space-between;
        gap: 12px;
    }

    #button a {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        width: 50%;
        height: 42px;
        font-size: 14px;
        font-weight: 600;
        text-decoration: none;
        border-radius: 6px;
        box-sizing: border-box;
        transition: all 0.2s ease-in-out;
    }

    #button a:first-child {
        background-color: #2563eb;
        color: #ffffff;
    }

    #button a:first-child:hover {
        background-color: #1d4ed8;
    }


    #button a:last-child {
        background-color: #ffffff;
        color: #475569;
        border: 1px solid #cbd5e1;
    }

    #button a:last-child:hover {
        background-color: #f8fafc;
        color: #1e293b;
        border-color: #94a3b8;
    }
</style>
</head>
<body>
<div id="join_mem">
<h2>회원가입</h2>
        <form name="member_form" method="post" action="insert.php"> 
    
        <div id="form_join">
            <div id="join1">
            <ul>
                <li> 
                    <label for="a1">아이디</label>
                    <input type="text" name="id" id="a1">
                    <a href="#" class="btn-check" onclick="check_id()">중복확인</a>
                </li>
                <li> 
                    <label for="a2">비밀번호</label>
                    <input type="password" name="pass" id="a2">
                </li>
                <li> 
                    <label for="a3">비밀번호 확인</label>
                    <input type="password" name="pass_confirm" id="a3">
                </li>
                <li> 
                    <label for="a4">이름</label>
                    <input type="text" name="name" id="a4">
                </li>
                <li> 
                    <label for="a5">전화번호</label>
                    <input type="text" name="hp" id="a5">
                </li>
            </ul>
            </div>
        </div>

        <div id="button">
            <a href="#" onclick="check_input()">가입하기</a>
            <a href="#" onclick="reset_form()">재작성</a>
        </div>
        </form>
    </div>

</body>
</html>