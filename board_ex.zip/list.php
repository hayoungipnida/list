
<?php 
  session_start(); 
?>
<!doctype html>
<html lang="ko">
<head> 
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>게시판 목록</title>
<link rel="stylesheet" href="css/reset.css">
<link rel="stylesheet" href="css/greet.css">

<style>
    body, html {
        width: 100%;
        height: 100%;
        margin: 0;
        padding: 0;
        background-color: #f8fafc;
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
    }

    #wrap {
        width: 100%;
        max-width: 900px;
        margin: 50px auto;
        padding: 0 20px;
        box-sizing: border-box;
    }

    #col2 {
        background: #ffffff;
        border: 1px solid #e2e8f0;
        border-radius: 12px;
        box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.05), 0 8px 10px -6px rgba(0, 0, 0, 0.05);
        padding: 35px 30px;
        box-sizing: border-box;
    }

    /* 상단 홈 링크 및 타이틀 */
    .nav-home {
        font-size: 11px;
        font-weight: 700;
        letter-spacing: 0.5px;
        margin-bottom: 8px;
    }
    .nav-home a {
        text-decoration: none;
        color: #94a3b8;
        transition: color 0.2s;
    }
    .nav-home a:hover {
        color: #2563eb;
    }

    #title {
        font-size: 22px;
        font-weight: 800;
        color: #1e293b;
        margin-bottom: 24px;
        letter-spacing: -0.5px;
    }

    /* 검색 바 및 총 게시글 수 */
    #list_search {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 20px;
        gap: 15px;
    }

    #list_search1 {
        font-size: 13px;
        font-weight: 600;
        color: #64748b;
    }

    .search_filter_group {
        display: flex;
        align-items: center;
        gap: 6px;
    }

    .search_filter_group select {
        height: 36px;
        border: 1px solid #cbd5e1;
        border-radius: 6px;
        color: #475569;
        font-size: 13px;
        padding: 0 10px;
        background-color: #ffffff;
        cursor: pointer;
    }

    .search_filter_group input[type="text"] {
        height: 36px;
        width: 160px;
        border: 1px solid #cbd5e1;
        border-radius: 6px;
        color: #1e293b;
        font-size: 13px;
        padding: 0 12px;
        box-sizing: border-box;
    }

    .search_filter_group input[type="text"]:focus {
        outline: none;
        border-color: #2563eb;
    }

    .btn-search-submit {
        height: 36px;
        padding: 0 16px;
        background-color: #1e293b;
        color: #ffffff;
        border: none;
        border-radius: 6px;
        font-size: 12px;
        font-weight: 600;
        cursor: pointer;
        transition: background-color 0.2s;
    }

    .btn-search-submit:hover {
        background-color: #0f172a;
    }

    /* 게시판 리스트 틀 헤더 */
    #list_top_title {
        background-color: #f1f5f9;
        border-top: 2px solid #cbd5e1;
        border-bottom: 1px solid #e2e8f0;
        border-radius: 6px 6px 0 0;
        padding: 12px 0;
    }

    #list_top_title ul {
        display: flex;
        margin: 0;
        padding: 0;
        list-style: none;
        text-align: center;
    }

    #list_top_title li {
        font-size: 12px;
        font-weight: 700;
        color: #475569;
    }

    /* 비율 고정 정렬 분할 */
    .col_num { width: 8%; text-align: center; }
    .col_subject { width: 52%; text-align: left; padding-left: 15px; box-sizing: border-box; }
    .col_id { width: 15%; text-align: center; }
    .col_date { width: 15%; text-align: center; }
    .col_hit { width: 10%; text-align: center; }

    /* 게시판 리스트 본문 아이템 */
    #list_content {
        margin-bottom: 25px;
    }

    #list_item {
        display: flex;
        align-items: center;
        padding: 14px 0;
        border-bottom: 1px solid #f1f5f9;
        transition: background-color 0.15s ease-in-out;
    }

    #list_item:hover {
        background-color: #f8fafc;
    }

    .col_num { font-size: 13px; color: #94a3b8; }
    
    .col_subject a {
        font-size: 14px;
        font-weight: 500;
        color: #334155;
        text-decoration: none;
        transition: color 0.2s;
    }

    .col_subject a:hover {
        color: #2563eb;
        text-decoration: underline;
    }

    .col_id { font-size: 13px; color: #475569; }
    .col_date { font-size: 13px; color: #64748b; }
    .col_hit { font-size: 13px; color: #94a3b8; }

    /* 하단 버튼 및 페이지 네이션 */
    #page_button {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-top: 30px;
        padding-top: 20px;
        border-top: 1px solid #e2e8f0;
    }

    #page_num {
        flex: 1;
        text-align: center;
        font-size: 13px;
        color: #94a3b8;
        display: flex;
        justify-content: center;
        align-items: center;
        gap: 4px;
    }

    #page_num a {
        text-decoration: none;
        color: #64748b;
        padding: 4px 10px;
        border-radius: 4px;
        transition: all 0.2s;
    }

    #page_num a:hover {
        background-color: #e2e8f0;
        color: #1e293b;
    }

    #page_num b {
        background-color: #2563eb;
        color: #ffffff;
        padding: 4px 10px;
        border-radius: 4px;
        font-weight: 700;
    }

    .direction_btn {
        font-weight: 600;
        color: #475569 !important;
    }

    #button {
        display: flex;
        gap: 8px;
    }

    .btn-action-list, .btn-action-write {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        height: 36px;
        padding: 0 16px;
        font-size: 12px;
        font-weight: 600;
        text-decoration: none;
        border-radius: 6px;
        box-sizing: border-box;
        transition: all 0.2s ease-in-out;
    }

    .btn-action-list {
        background-color: #ffffff;
        color: #475569;
        border: 1px solid #cbd5e1;
    }

    .btn-action-list:hover {
        background-color: #f8fafc;
        border-color: #94a3b8;
    }

    .btn-action-write {
        background-color: #2563eb;
        color: #ffffff;
        border: none;
    }

    .btn-action-write:hover {
        background-color: #1d4ed8;
    }
</style>
</head>
<body>

<?php
include "dbconn.php";
  $mode = isset($_GET['search']) ? $_GET['search'] : '';
  $page = isset($_GET['page']) ? $_GET['page'] : '';
  $find = isset($_POST['find']) ? $_POST['find'] : '';
  $search = isset($_POST['search']) ? $_POST['search'] : '';

  if (isset($_GET["mode"]))
    $mode = $_GET["mode"];
  else
    $mode = "";

$scale=10;

if($mode == "search")
{
   if(!$search)
    {
      echo("
        <script>
         window.alert('검색할 단어를 입력해 주세요!');
           history.go(-1);
        </script>
      ");
      exit;
    }
 $sql = "select * from boardlist where $find 
       like '%$search%' order by num desc";   
}
else
{
  $sql = "select * from boardlist order by num desc";
}
/** @var mysqli $connect */
$result = mysqli_query( $connect,$sql);
$total_record = mysqli_num_rows($result); 
if ($total_record % $scale == 0)     
    $total_page = floor($total_record/$scale);
else
    $total_page = floor($total_record/$scale) + 1;
  
if (!$page) 
    $page = 1;

    $start = ($page - 1) * $scale;     
    $number = $total_record - $start;   
?>

<div id="wrap">
 <p class="nav-home"><a href="main.html">HOME</a></p>
 <div id="col2">
  <div id="title">BOARD</div>
  
  <form name="board_form" method="post" action="list.php?mode=search">
    <div id="list_search">
     <div id="list_search1">▷ 총 <?= $total_record ?>개의 게시물이 있습니다</div>
     <div class="search_filter_group">
       <select name="find">
         <option value='subject'>제목</option>
         <option value='content'>내용</option>
         <option value='id'>아이디</option>
         <option value='name'>이름</option>
       </select>
       <input type="text" name="search" placeholder="검색어 입력">
       <button type="submit" class="btn-search-submit">검색</button>
     </div>
    </div>
  </form>

  <div id="list_top_title">
    <ul>
      <li class="col_num">번호</li>
      <li class="col_subject">제목</li>
      <li class="col_id">글쓴이</li>
      <li class="col_date">등록일</li>
      <li class="col_hit">조회</li>
    </ul>
  </div>

  <div id="list_content">
<?php
for($i=$start; $i<$start+$scale && $i < $total_record; $i++)                    
   {
      mysqli_data_seek($result, $i);       
      $row = mysqli_fetch_array($result);       
      
    $item_num     = $row['num'];
    $item_id      = $row['id'];
    $item_name    = $row['name'];
    $item_hit     = $row['hit'];
    $item_date    = $row['regist_day'];
    $item_date    = substr($item_date, 0, 10);  
    $item_subject = str_replace(" ", "&nbsp;", $row['subject']);
?>
    <div id="list_item">
        <div class="col_num"><?= $number ?></div>
        <div class="col_subject">
            <a href="view.php?num=<?=$item_num?>&page=<?=$page?>"><?= $item_subject ?></a>
        </div>
        <div class="col_id"><?= $item_id ?></div>
        <div class="col_date"><?= $item_date ?></div>
        <div class="col_hit"><?= $item_hit ?></div>
    </div>
<?php
       $number--;
   }
?>
  </div>

  <div id="page_button">
    <div id="page_num">
      <a href="#" class="direction_btn">◀ 이전</a> 
<?php
   for ($i=1; $i<=$total_page; $i++)
   {
    if ($page == $i)
    {
      echo "<b> $i </b>";
    }
    else
    { 
      echo "<a href='list.php?page=$i'> $i </a>";
    }      
   }
?>      
      <a href="#" class="direction_btn">다음 ▶</a>
    </div>

    <div id="button">
  <?php if(isset($_SESSION['userid'])): ?>
    <a href="write_form.php" class="btn-action-write">글쓰기</a>
  <?php else: ?>
    <a href="login_form.php" class="btn-action-list">로그인</a>
  <?php endif; ?>
</div>

  </div>

 </div>
</div>

</body>
</html>