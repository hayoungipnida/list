<?php
if (isset($_SESSION['last_activity'])) {
    $inactive = 1800;
    if (time() - $_SESSION['last_activity'] > $inactive) {
        session_destroy();
        echo "<script>alert('세션이 만료되었습니다. 다시 로그인해주세요.'); location.href='login_form.php';</script>";
        exit;
    }
}
$_SESSION['last_activity'] = time();
?>