<?php 
  session_start(); 
  include "dbconn.php";

  $num=$_GET['num'];
  $page=$_GET['page'];
 /** @var mysqli $connect */
$sql = "select * from boardlist where num=$num"; 
$result = mysqli_query( $connect,$sql);
$row = mysqli_fetch_array($result);  
$item_num     = $row['num'];
$item_id      = $row['id'];
$item_name    = $row['name'];
$item_hit     = $row['hit'];
$item_date = date("Y-m-d (H:i)", strtotime($row['regist_day']));
$item_subject = str_replace(" ", "&nbsp;", $row['subject']);
$item_content = $row['content'];
$is_html      = $row['is_html'];

if ($is_html!="y")
{
$item_content = 
str_replace(" ", "&nbsp;", $item_content);
$item_content = 
str_replace("\n", "<br>", $item_content);
}   
    $new_hit = $item_hit + 1;
$sql = "update boardlist set hit=$new_hit 
where num=$num";   // 글 조회수 증가시킴
    mysqli_query( $connect,$sql);
?>
<!DOCTYPE html>
<html lang="ko">
<head> 
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>게시글 보기</title>
<link rel="stylesheet" href="css/reset.css">
<link rel="stylesheet" href="css/greet.css">

<style>
    body, html {
        width: 100%;
        height: 100%;
        margin: 0;
        padding: 0;
        background-color: #f8fafc;
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
    }

    #wrap {
        width: 100%;
        max-width: 800px;
        margin: 50px auto;
        padding: 0 20px;
        box-sizing: border-box;
    }

    #content #col2 {
        width: 100%;
    }

    /* 상세 보기 카드 박스 */
    #view_box {
        background: #ffffff;
        border: 1px solid #e2e8f0;
        border-radius: 12px;
        box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.05), 0 8px 10px -6px rgba(0, 0, 0, 0.05);
        padding: 40px 35px;
        box-sizing: border-box;
    }

    /* 상단 제목 및 메타 정보 영역 */
    #view_title {
        padding-bottom: 20px;
        border-bottom: 2px solid #e2e8f0;
        margin-bottom: 30px;
    }

    #view_title1 {
        font-size: 22px;
        font-weight: 700;
        color: #1e293b;
        line-height: 1.4;
        word-break: break-all;
        letter-spacing: -0.5px;
        margin-bottom: 12px;
    }

    #view_title2 {
        font-size: 13px;
        color: #64748b;
        font-weight: 500;
        display: flex;
        align-items: center;
        gap: 8px;
    }

    #view_title2 .divider {
        color: #cbd5e1;
    }

    /* 본문 내용 영역 */
    #view_content {
        font-size: 15px;
        color: #334155;
        line-height: 1.7;
        min-height: 280px;
        word-break: break-all;
        padding: 10px 5px;
        box-sizing: border-box;
    }

    /* 하단 버튼 그룹 */
    #view_button {
        margin-top: 40px;
        padding-top: 20px;
        border-top: 1px solid #e2e8f0;
        display: flex;
        justify-content: flex-end;
        align-items: center;
        gap: 8px;
    }

    /* 공통 CSS 버튼 컴포넌트 */
    .btn-view {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        height: 36px;
        padding: 0 16px;
        font-size: 12px;
        font-weight: 600;
        text-decoration: none;
        border-radius: 6px;
        box-sizing: border-box;
        cursor: pointer;
        transition: all 0.2s ease-in-out;
    }

    /* 기본 서브 버튼 (목록, 수정) */
    .btn-view-default {
        background-color: #ffffff;
        color: #475569;
        border: 1px solid #cbd5e1;
    }

    .btn-view-default:hover {
        background-color: #f8fafc;
        border-color: #94a3b8;
        color: #1e293b;
    }

    /* 경고/삭제 버튼 (연한 레드 톤) */
    .btn-view-danger {
        background-color: #ffffff;
        color: #ef4444;
        border: 1px solid #fca5a5;
    }

    .btn-view-danger:hover {
        background-color: #fef2f2;
        border-color: #ef4444;
    }

    /* 메인 포인트 버튼 (글쓰기 - 블루) */
    .btn-view-primary {
        background-color: #2563eb;
        color: #ffffff;
        border: none;
    }

    .btn-view-primary:hover {
        background-color: #1d4ed8;
    }
</style>
</head>
<body>

<div id="wrap">
  <div id="content"> 
    <div id="col2">
      
      <div id="view_box">
        
        <div id="view_title">
          <div id="view_title1"><?= $item_subject ?></div>
          <div id="view_title2">
            <span>👤 <?= $item_id ?></span>
            <span class="divider">|</span>
            <span>👀 조회 : <?= $item_hit ?></span>
            <span class="divider">|</span>
            <span>📅 <?= $item_date ?></span>
          </div>
        </div>

        <div id="view_content">
          <?= $item_content ?>
        </div>

        <div id="view_button">
          <a href="list.php?page=<?=$page?>" class="btn-view btn-view-default">목록보기</a>
          
          <?php
            $userid = isset($_SESSION['userid']) ? $_SESSION['userid'] : '';
            $item_id = $row['id'];
            if($userid && $userid == $item_id) {
          ?>
            <a href="modify_form.php?num=<?=$num?>&page=<?=$page?>" class="btn-view btn-view-default">수정하기</a>
            <a href="delete.php?num=<?=$num?>&page=<?=$page?>" class="btn-view btn-view-danger">삭제하기</a>          
          <?php
            }
          ?>

          <?php
            if($userid) {
          ?>
            <a href="write_form.php" class="btn-view btn-view-primary">새 글 쓰기</a>
          <?php
            }
          ?>
        </div>

      </div> </div> </div> </div> </body>
</html>