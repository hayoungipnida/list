create table mb1(
id varchar(10)  not null,
pass varchar(255) not null,
name varchar(8) not null,
hp varchar(20) not null,
primary key(id)
)engine=innoDB charset=utf8;