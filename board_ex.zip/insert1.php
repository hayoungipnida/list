<? 
session_start();
include "session_check.php";
 ?>
<meta charset="utf-8">
<?

   // $userid=$_POST['userid'];
   $userid=$_SESSION['userid'];
	$username=$_SESSION['username'];
	$subject=$_POST['subject'];
	$content=$_POST['content'];


	if(!$_SESSION['userid'] ){
		echo("
		<script>
	     window.alert('로그인 후 이용해 주세요.')
	     history.go(-1)
	   </script>
		");
		exit;
	}

		if(!$_POST['subject'] ){
		echo("
	   <script>
	     window.alert('제목을 입력하세요.')
	     history.go(-1)
	   </script>
		");
	 exit;
	}

	
		if(!$_POST['content'] ){
		echo("
	   <script>
	     window.alert('내용을 입력하세요.')
	     history.go(-1)
	   </script>
		");
	 exit;
	}

	include "dbconn.php";       
$page = 1;    
	
$mode=$_GET['modify'];
$num=$_GET['num'];

if (isset($_GET["mode"]))
    $mode = $_GET["mode"];
  else
    $mode = "";

$html_ok = "";
	if ($mode=="modify")
	{
		$sql = "update boardlist set subject='$subject', content='$content' where num=$num";
	}
	else
	{
		if ($html_ok=="y")
		{
			$is_html = "y";
		}
		else
		{
			$is_html = "";
			$content = htmlspecialchars($content);
		}

		$sql = "insert into boardlist (id, name, subject, content, is_html) ";
		$sql .= "values('$userid', '$username', '$subject', '$content', '$is_html')";
	}
/** @var mysqli $connect */
	mysqli_query( $connect,$sql);  // $sql 에 저장된 명령 실행
	mysqli_close($connect);                // DB 연결 끊기

	echo "
	   <script>
	    location.href = 'list.php?page=$page';
	   </script>
	";
?>