create table scorenew01(
    ban varchar(2) null,             
    id varchar(8) not null,          
    name varchar(12) null,           
    kor int not null default 0,       
    eng int not null default 0,       
    mat int not null default 0,        
    sum int,                         
    avg float,                        
    rt varchar(8),
	primary key(id)
)engine=innDB charset=utf8;