<!doctype html>
<html lang="ko">
<head>
<meta charset="utf-8">
<title>html5문서</title>
<style>
 tr,td {text-align:center;}
 table {padding:20px;box-sizing:border-box;}
 .tb {border:none;}
 tr, td {border:none;}
</style>
</head>
<body>
<h3>데이터 입력 하기</h3>
<form action="insert.php" method='post'>
<table width="900" border="1" >
<tr>
  <td>
  반 : <input type="text" size="6" name="ban">
  ID : <input type="text" size="6" name="id">
  이름 : <input type="text" size="6" name="name">
  KOR : <input type="text" size="6" name="kor">
  ENG : <input type="text" size="6" name="eng">
  MAT : <input type="text" size="6" name="mat">  
  </td> 
  <td><input type="submit" value="입력하기"></td>
</tr>

</table>
</form>
<!--성적 출력하기-->
<h3>성적 출력 하기</h3>
<!--성적 정렬하기-->
<p><a href="score_t.php?mode=big_first">[평균 내림차순 정리]</a>
<p><a href="score_t.php?mode=small_first">[평균 오름차순 정리]</a></p>

<table width="900" border="1" class="tb">
  <tr>
    <td>반</td>
    <td>ID</td>
    <td>이름</td>
    <td>KOR</td>
    <td>ENG</td>
    <td>MAT</td>
    <td>합계</td>
    <td>평균</td>
    <td>결과</td>
  </tr>
  <?php
  include "dbconn.php";
  $mode = $_GET['mode'];
if ($mode == "big_first")
  $sql = "select * from scorenew01 order by avg desc";
else if ($mode == "small_first")
  $sql = "select * from scorenew01 order by avg";
else
  $sql = "select * from scorenew01";

  $result = mysqli_query($connect,$sql);

  while($row = $result->fetch_assoc()){
    $id = $row['id'];
    echo "<tr>";
    echo "<td>".$row["ban"]."</td>";
    echo "<td>".$row["id"]."</td>";
    echo "<td>".$row["name"]."</td>";
    echo "<td>".$row["kor"]."</td>";
    echo "<td>".$row["eng"]."</td>";
    echo "<td>".$row["mat"]."</td>";
    echo "<td>".$row["sum"]."</td>";
    echo "<td>".$row["avg"]."</td>";
    echo "<td>".$row["rt"]."</td>";
    echo "<td><a href='delete.php?id=$id'>[삭제]</a></td>";
    echo "</tr>";
  }
  mysqli_close($connect);

  ?>

  </table>
  <h3>반별 과목 평균</h3>
  <table width="900" border = "1">
    <tr>
      <td>반</td>
      <td>국어 평균</td>
      <td>영어 평균</td>
      <td>수학 평균</td>
</tr>
<?php
include "dbconn.php";
$sql = "SELECT ban,
ROUND(AVG(kor),1) AS kor_avg,
ROUND(AVG(eng),1) AS eng_avg,
ROUND(AVG(mat),1) AS mat_avg
FROM scorenew01
GROUP BY ban";

$result = mysqli_query($connect, $sql);

while ($row = mysqli_fetch_assoc($result)) {
          echo "<tr>";
          echo "<td>" . $row['ban'] . "반</td>"; 
          echo "<td>" . $row['kor_avg'] . "</td>"; 
          echo "<td>" . $row['eng_avg'] . "</td>"; 
          echo "<td>" . $row['mat_avg'] . "</td>";
          echo "</tr>";}


?>
</table>

</body>
</html>
