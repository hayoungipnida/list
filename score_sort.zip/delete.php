<?php
include "dbconn.php";
$id=$_GET['id']; 
$sql = "delete from scorenew01 where id= '$id'";
mysqli_query( $connect, $sql);
mysqli_close($connect);
Header("Location:score_t.php");
?>