<meta charset="utf-8">
<?php
$ban=$_POST['ban'];
$id=$_POST['id'];
$name=$_POST['name'];
$kor=intval($_POST['kor']);
$eng=intval($_POST['eng']);
$mat=intval($_POST['mat']);
include "dbconn.php";
$sql="select * from scorenew01";
$result = mysqli_query( $connect,$sql);
$sum = $kor + $eng + $mat;
$avg = round($sum/3,1);

if($avg >= 90){
    $rt = "합격";
} else {
    $rt = "불합격";
}

$sql = "insert into scorenew01(ban,id,name,kor,eng,mat,sum,avg,rt) values";
$sql .= "('$ban','$id', '$name',$kor,$eng,$mat,$sum,$avg,'$rt')";
$result = mysqli_query($connect,$sql);
mysqli_close($connect);
echo "
<script>
location.href = 'score_t.php';
</script>
";
?>