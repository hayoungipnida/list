document.addEventListener("DOMContentLoaded", function(){
    const tagged = {};
    document.querySelectorAll("#gallery img").forEach(function(img){
        const tags = img.dataset.tags;
        if (tags) {
            tags.split(',').forEach(function(tagName){
                if(tagged[tagName]== null) {
                    tagged[tagName] = [];
                }
                tagged[tagName].push(img);
            });
        }
    });
    
    document.querySelectorAll(".first a").forEach(function(btn){
        btn.addEventListener("click", function(e){
            e.preventDefault();
            document.querySelectorAll("#button li").forEach(li => {
            });
            this.classList.remove("active");
             this.classList.add("active");
        });
       
        document.querySelectorAll("#gallery img").forEach(img => {
            img.style.display="";
        });
    });

    document.querySelectorAll("#button li").forEach(function(li){
        li.addEventListener("click", function(){
            document.querySelectorAll(".first a").forEach(a => {
                a.classList.remove("active");
            });
            this.classList.add("active");
            const tagName=this.textContent.trim();
            this.parentElement.querySelectorAll("li").forEach(sibling =>{
                if(sibling !== this) sibling.classList.remove("active");
            });
            document.querySelectorAll("#gallery img").forEach(img => {
                img.style.display="none";
            });
            if (tagged[tagName]){
                tagged[tagName].forEach(img => {
                    img.style.display="";

                });
            }
        });
    })
});