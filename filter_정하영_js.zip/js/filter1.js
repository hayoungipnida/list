document.addEventListener("DOMContentLoaded", function(){
  const cache=[];
  
  document.querySelectorAll("#gallery img").forEach(function(img){
    cache.push({
        element: img,
        text: img.alt.trim().toLowerCase()
    });
  });

  function filter(){
    const query = this.value.trim().toLowerCase();
    cache.forEach(function(img){
        let index = 0;
        if(query){
            index=img.text.indexOf(query);

        }
        img.element.style.display = index == -1 ? 'none' : '';
    });
  }
  document
  .getElementById("filter-search")
  .addEventListener("keyup",filter);
});