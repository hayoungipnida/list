let lastScrollTop = 0;
const delta = 5;
const fixBox = document.querySelector('.bottomNav');
const fixBoxHeight = fixBox.offsetHeight;
let didScroll;


window.onscroll = function(e) {
    didScroll = true;
};


setInterval(function(){
    if(didScroll){
        hasScrolled();
        didScroll = false;
    }
}, 250);

function hasScrolled(){
const nowScrollTop = window.scrollY;
if(Math.abs(lastScrollTop - nowScrollTop) <= delta){
        return;
}
if(nowScrollTop > lastScrollTop && nowScrollTop > fixBoxHeight){
        fixBox.classList.remove('show');
  }else{
   if(nowScrollTop+window.innerHeight<document.body.offsetHeight){
            fixBox.classList.add('show');
        }
    }
       lastScrollTop = nowScrollTop;
}

class ThemeController {
    constructor(){
        this.article = document.querySelector("article");
        this.contents = document.querySelectorAll(".contents");
        this.btn = document.querySelector(".btn");
        this.mode = "day"; //현재 상태
    }
    setArticleColor(color) {
        this.article.style.backgroundColor = color;
    }
    setContentsColor(color) {
        this.contents.forEach(el => {
            el.style.color = color;
        });
    }
    setBtn(color) {
        this.btn.style.backgroundColor=color;
    }

    setBtnc(color){
        this.btn.style.color = color;
    }

    toggle(self) {
        if (this.mode === "day"){
            this.setArticleColor("#4F5051");
            this.setContentsColor("#ebebeb");
            this.setBtn("#4f5051")
            this.setBtnc("#ebebeb")

            this.mode = "night";
            self.value = "Day";

        } else {
            this.setArticleColor("#fff");
            this.setContentsColor("black");
            this.setBtn("#fff")
            this.setBtnc("#ACA39A")

            this.mode = "day";
            self.value = "Night";

        }
    }

}

const theme = new ThemeController();
function day_night_handler(self){
    theme.toggle(self);
}
